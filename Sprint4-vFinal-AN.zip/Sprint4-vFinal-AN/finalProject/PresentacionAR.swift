//
//  ARTutorialReciboViewController.swift
//  EcoBook
//
//  Created by Ali Bryan Villegas Zavala on 4/30/19.
//  Copyright © 2019 Tec de Monterrey. All rights reserved.
//

import UIKit
import SceneKit
import ARKit

class PresentacionAR: UIViewController, ARSCNViewDelegate {
    var videoNode:SKVideoNode?
    var videoPlayer:AVPlayer?
    var recibirVideoRA = ""
    weak var activityIndicator: UIActivityIndicatorView?
    
    @IBOutlet var sceneView: ARSCNView!
    
    @IBAction func playVideo(sender: AnyObject) {
        videoNode?.play()
    }
    
    @IBAction func pauseVideo(sender: AnyObject) {
        videoNode?.pause()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        sceneView.alpha = 0
        view.backgroundColor = #colorLiteral(red: 0.3173043132, green: 0.4565047026, blue: 0.5755147934, alpha: 1)
        
        sceneView.isPlaying = false
        sceneView.session.delegate = self as? ARSessionDelegate
        
        
        let activityIndicator = UIActivityIndicatorView(style: .gray)
        activityIndicator.startAnimating()
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(activityIndicator)
        NSLayoutConstraint.activate([view.centerXAnchor.constraint(equalTo: activityIndicator.centerXAnchor, constant: 0),
                                     view.centerYAnchor.constraint(equalTo: activityIndicator.centerYAnchor, constant: 0)])
        self.activityIndicator = activityIndicator
        
        sceneView.autoenablesDefaultLighting = true
        
    }
    
    private func loadScene() {
        
        SCNTransaction.begin()
        SCNTransaction.disableActions = true
        
        
        // Set the view's delegate
        sceneView.delegate = self
        
        // Show statistics such as fps and timing information
        sceneView.showsStatistics = false
        
        SCNTransaction.commit()
        
        self.isLoading = false
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let configuration = ARImageTrackingConfiguration()
        guard let imagenesMarcador = ARReferenceImage.referenceImages(inGroupNamed: "AR Resources", bundle: nil)
            else{
                fatalError("No se encontró la imagen marcadora")
        }
        
        configuration.trackingImages = imagenesMarcador
        
        // Create a session configuration
        //let configuration = ARWorldTrackingConfiguration()
        
        // Run the view's session
        sceneView.session.run(configuration)
    }
    
    func renderer(_ renderer: SCNSceneRenderer, didAdd node: SCNNode, for anchor: ARAnchor){
        if let anchor = anchor as? ARImageAnchor{
            let imagenReferencia = anchor.referenceImage
            agregarModelo(to:node, refImage: imagenReferencia)
            if(videoNode != nil){
                videoNode!.play()
            }
            
        }
        else{
            videoNode?.pause()
            //node.removeFromParentNode()
        }
    }
    
    private func agregarModelo(to node:SCNNode,refImage:ARReferenceImage ){
        DispatchQueue.global().async {
            //currentFrame es la imagen actual de la camara
            guard let currentFrame = self.sceneView.session.currentFrame else {return}
            
            //let path = Bundle.main.path(forResource: "CheeziPuffs", ofType: "mov")
            //let url = URL(fileURLWithPath: path!)
            
            let moviePath = self.recibirVideoRA
            let url = URL(string: moviePath)
            let player = AVPlayer(url: url!)
            player.volume = 0.5
            print(player.isMuted)
            
            // crear un nodo capaz de reporducir un video
            let videoNodo = SKVideoNode(avPlayer: player)                //let videoNodo = SKVideoNode(fileNamed: "CheeziPuffs.mov")
            //let videoNodo = SKVideoNode(avPlayer: player)
            videoNodo.play() //ejecutar play al momento de presentarse
            self.videoNode = videoNodo
            //crear una escena sprite kit, los parametros estan en pixeles
            let spriteKitEscene =  SKScene(size: CGSize(width: 640, height: 480))
            spriteKitEscene.addChild(videoNodo)
            
            //colocar el videoNodo en el centro de la escena tipo SpriteKit
            videoNodo.position = CGPoint(x: spriteKitEscene.size.width/2, y: spriteKitEscene.size.height/2)
            videoNodo.size = spriteKitEscene.size
            
            //crear una pantalla 4/3, los parametros son metros
            let pantalla = SCNPlane(width: 25, height: 20)
            
            //pantalla.firstMaterial?.diffuse.contents = UIColor.blue
            //modificar el material del plano
            pantalla.firstMaterial?.diffuse.contents = spriteKitEscene
            //permitir ver el video por ambos lados
            pantalla.firstMaterial?.isDoubleSided = true
            
            let pantallaPlanaNodo = SCNNode(geometry: pantalla)
            //identificar en donde se ha tocado el currentFrame
            var traduccion = matrix_identity_float4x4
            //definir un metro alejado del dispositivo
            traduccion.columns.3.z = -1.0
            pantallaPlanaNodo.simdTransform = matrix_multiply(currentFrame.camera.transform, traduccion)
            
            pantallaPlanaNodo.eulerAngles = SCNVector3(83, 0, 0)
            pantallaPlanaNodo.position = SCNVector3(pantallaPlanaNodo.position.x,pantallaPlanaNodo.position.y, pantallaPlanaNodo.position.z)
            node.addChildNode(pantallaPlanaNodo)
            
            
        }
    }
    
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        // Pause the view's session
        sceneView.session.pause()
    }
    
    
    // MARK: - ARSCNViewDelegate
    
    /*
     // Override to create and configure nodes for anchors added to the view's session.
     func renderer(_ renderer: SCNSceneRenderer, nodeFor anchor: ARAnchor) -> SCNNode? {
     let node = SCNNode()
     
     return node
     }
     */

    
    func session(_ session: ARSession, didFailWithError error: Error) {
        // Present an error message to the user
        
    }
    
    func sessionWasInterrupted(_ session: ARSession) {
        // Inform the user that the session has been interrupted, for example, by presenting an overlay
        
    }
    
    func sessionInterruptionEnded(_ session: ARSession) {
        // Reset tracking and/or remove existing anchors if consistent tracking is required
        
    }
    var isLoading = true
    var hasLoaded = false
}



extension PresentacionAR: ARSessionDelegate {
    
    func session(_ session: ARSession, didUpdate frame: ARFrame) {
        
        // Waiting until after the session starts prevents objects from jumping around
        if hasLoaded == false {
            hasLoaded = true
            
            loadScene()
            
        } else if isLoading == false {
            guard let activityIndicator = self.activityIndicator else { return }
            
            DispatchQueue.main.async {
                UIView.animate(withDuration: 0.40, animations: { [weak self] in
                    self?.sceneView.alpha = 1
                    activityIndicator.alpha = 0
                    }, completion: { _ in
                        activityIndicator.removeFromSuperview()
                })
            }
        }
    }
}

