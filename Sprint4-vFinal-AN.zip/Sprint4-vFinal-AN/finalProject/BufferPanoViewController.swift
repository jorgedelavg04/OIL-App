//
//  BufferPanoViewController.swift
//  finalProject
//
//  Created by ITESM CCM on 4/8/19.
//  Copyright © 2019 ITESM CCM. All rights reserved.
//

import UIKit

class BufferPanoViewController: UIViewController {
    
    @IBOutlet weak var imagen: UIImageView!
    
    var recibirPano = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let url = URL(string: recibirPano)
        imagen.kf.indicatorType = .activity
        imagen.kf.setImage(with: url) { result in
            // `result` is either a `.success(RetrieveImageResult)` or a `.failure(KingfisherError)`
            switch result {
            case .success(let value):
                print(value.image)
                let button = UIButton(frame: CGRect(x: 100, y: 600, width: 200, height: 50))
                button.backgroundColor = UIColor(red:0.61, green:0.30, blue:0.12, alpha:1.0)
                button.setTitle("Ir a tour virtual", for: .normal)
                button.addTarget(self, action: #selector(self.buttonAction), for: .touchUpInside)
                button.layer.cornerRadius = 20
                
                self.view.addSubview(button)
                
            case .failure(let error):
                print(error) // The error happens
            }
        }
        // Do any additional setup after loading the view.
    }
    
    @objc func buttonAction(sender: UIButton!) {
        self.performSegue(withIdentifier: "showPano", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if(segue.identifier == "showPano") {
            
            let panoView = (segue.destination as! PanoramaViewController)
            panoView.recibirPano = imagen.image
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
