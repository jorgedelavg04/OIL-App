
//  MachineLearningController.swift
//  finalProject
//
//  Created by ITESM CCM on 5/15/19.
//  Copyright © 2019 ITESM CCM. All rights reserved.
//

import UIKit
import SceneKit
import ARKit
import Vision

class MachineLearningController: UIViewController, ARSCNViewDelegate  {
    
    private var hitTestResult: ARHitTestResult!
    private var OILModel = OIL_ML_1()
    private var visionRequests = [VNRequest]()
    var desc = ""
    var obj = ""
    weak var activityIndicator: UIActivityIndicatorView?
    let mlURL = "http://martinmolina.com.mx/201911/data/memelords/ml.json"
    //1. cargar el modelo de la red
    //2. registrar el gesto de tap
    //3. instanciar el modelo y enviar la imagen
    //4. Presentar los datos resultados del modelo
    
   
    @IBOutlet weak var objView: UILabel!
    @IBOutlet weak var descripcionView: UITextView!
    
    @IBAction func tapEjecutado(_ sender: UITapGestureRecognizer) {
        //obtener la vista donde se va a trabajar
        let vista = sender.view as! ARSCNView
        //ubicar el toque en el centro de la vista
        let ubicacionToque = self.sceneView.center
        //obtener la imagen actual
        guard let currentFrame = vista.session.currentFrame else {return}
        //obtener los nodos que fueron tocados por el rayo
        let hitTestResults = vista.hitTest(ubicacionToque, types: .featurePoint)
        
        if (hitTestResults .isEmpty){
            //no se toco nada
            return}
        guard let hitTestResult = hitTestResults.first else{
            return
            
        }
        //obtener la imagen capturada en formato de buffer de pixeles
        let imagenPixeles = currentFrame.capturedImage
        self.hitTestResult = hitTestResult
        performVisionRequest(pixelBuffer: imagenPixeles)
    }
    
    private func performVisionRequest(pixelBuffer: CVPixelBuffer)
    {
        
        //inicializar el modelo de ML al modelo usado, en este caso resnet
        let visionModel = try! VNCoreMLModel(for: OILModel.model)
        let request = VNCoreMLRequest(model: visionModel) { request, error in
            
            if error != nil {
                //hubo un error
                return}
            guard let observations = request.results else {
                //no hubo resultados por parte del modelo
                return
                
            }
            //obtener el mejor resultado
            let observation = observations.first as! VNClassificationObservation
            
            self.obj = observation.identifier
            
            print("Nombre \(observation.identifier) confianza \(observation.confidence)")
            
            
            
        }
        //la imagen que se pasará al modelo sera recortada para quedarse con el centro
        request.imageCropAndScaleOption = .centerCrop
        self.visionRequests = [request]
        
        let imageRequestHandler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .upMirrored, options: [:])
        DispatchQueue.global().async {
            try! imageRequestHandler.perform(self.visionRequests)
            
        }
        
        self.desplegarTexto()
        
        
        
    }
    private func desplegarTexto()
    {
        
        var nuevoArray:[String:String]?
        let datosNubeURL = URL(string: self.mlURL)
        let datos = try? Data(contentsOf: datosNubeURL!)
        nuevoArray = try! JSONSerialization.jsonObject(with: datos!) as? [String:String]
        
        
        
        /*do{
         try self.desc = nuevoArray![self.obj] as! String
        } catch{
                print("error")
                self.desc = ""
            }*/
        
        
        self.objView.text = obj
        guard case self.desc = nuevoArray?[self.obj] else{
            self.desc = ""
            return
        }
        self.descripcionView.text = desc
        
    }
    
    @IBOutlet weak var sceneView: ARSCNView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        sceneView.alpha = 0
        view.backgroundColor = #colorLiteral(red: 0.3173043132, green: 0.4565047026, blue: 0.5755147934, alpha: 1)
        
        sceneView.isPlaying = false
        sceneView.session.delegate = self
        
        let activityIndicator = UIActivityIndicatorView(style: .gray)
        activityIndicator.startAnimating()
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(activityIndicator)
        NSLayoutConstraint.activate([view.centerXAnchor.constraint(equalTo: activityIndicator.centerXAnchor, constant: 0),
                                     view.centerYAnchor.constraint(equalTo: activityIndicator.centerYAnchor, constant: 0)])
        self.activityIndicator = activityIndicator
        
        sceneView.autoenablesDefaultLighting = true
        
        let alert = UIAlertController(title: "Hint", message: "Localiza una figura y da tap en la pantalla", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        self.present(alert, animated: true)
    }
    
    private func loadScene() {
        
        SCNTransaction.begin()
        SCNTransaction.disableActions = true
        
        
        
        // Set the view's delegate
        sceneView.delegate = self
        
        // Show statistics such as fps and timing information
        sceneView.showsStatistics = true
        
        // Create a new scene
        let scene = SCNScene()
        // Set the scene to the view
        sceneView.scene = scene
        
        SCNTransaction.commit()
        
        self.isLoading = false
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Create a session configuration
        let configuration = ARWorldTrackingConfiguration()

        // Run the view's session
        sceneView.session.run(configuration)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        // Pause the view's session
        sceneView.session.pause()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Release any cached data, images, etc that aren't in use.
    }
    
    // MARK: - ARSCNViewDelegate
    
    /*
     // Override to create and configure nodes for anchors added to the view's session.
     func renderer(_ renderer: SCNSceneRenderer, nodeFor anchor: ARAnchor) -> SCNNode? {
     let node = SCNNode()
     
     return node
     }
     */
    
    func session(_ session: ARSession, didFailWithError error: Error) {
        // Present an error message to the user
        
    }
    
    func sessionWasInterrupted(_ session: ARSession) {
        // Inform the user that the session has been interrupted, for example, by presenting an overlay
        
    }
    
    func sessionInterruptionEnded(_ session: ARSession) {
        // Reset tracking and/or remove existing anchors if consistent tracking is required
        
    }
    var isLoading = true
    var hasLoaded = false
    
}
extension MachineLearningController: ARSessionDelegate {
    
    
    
    func session(_ session: ARSession, didUpdate frame: ARFrame) {
        
        // Waiting until after the session starts prevents objects from jumping around
        if hasLoaded == false {
            hasLoaded = true
            loadScene()
            
            
            
        } else if isLoading == false {
            guard let activityIndicator = self.activityIndicator else { return }
            
            DispatchQueue.main.async {
                UIView.animate(withDuration: 0.40, animations: { [weak self] in
                    self?.sceneView.alpha = 1
                    activityIndicator.alpha = 0
                    }, completion: { _ in
                        activityIndicator.removeFromSuperview()
                })
            }
        }
    }
}

