//
//  SecondViewController.swift
//  finalProject
//
//  Created by ITESM CCM on 3/7/19.
//  Copyright © 2019 ITESM CCM. All rights reserved.
//


import UIKit
import MapKit
import CoreLocation


class SecondViewController: UIViewController, CLLocationManagerDelegate {
    @IBOutlet weak var mapa: MKMapView!
    
    private let locationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        
        locationManager.requestWhenInUseAuthorization()
        mapa.mapType = MKMapType.standard
        let cl = CLLocationCoordinate2DMake(19.2837247, -99.1357039)
        mapa.region=MKCoordinateRegion(center: cl, latitudinalMeters:1000, longitudinalMeters:1000)
        let rest = MKPointAnnotation()
        rest.coordinate = cl
        rest.title = "CEDETEC"
        rest.subtitle = "Open Innovation Labs"
        mapa.addAnnotation(rest)
        
        mapa.showsCompass = true
        mapa.showsScale = true
        mapa.showsTraffic = true
        mapa.isZoomEnabled = true
    }
    func locationManager(_ manager: CLLocationManager,
                         didChangeAuthorization status: CLAuthorizationStatus) {
        if status == .authorizedWhenInUse{
            locationManager.startUpdatingLocation()
            mapa.showsUserLocation = true
        } else {
            locationManager.stopUpdatingLocation()
            mapa.showsUserLocation = false
        }
    }
    
    
}



