//
//  PanoramaViewController.swift
//  finalProject
//
//  Created by Mac Produccion on 3/20/19.
//  Copyright © 2019 ITESM CCM. All rights reserved.
//

import UIKit
import CTPanoramaView
import Kingfisher

class PanoramaViewController: UIViewController {

    var recibirPano = UIImage(named: "tec.png")
    
    @IBOutlet weak var imagen: UIImageView!
    
    @IBOutlet var panoramaVIew: CTPanoramaView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //imagen.downloaded(from: recibirPano)
        
        panoramaVIew.image = recibirPano
        panoramaVIew.controlMethod = .motion
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
