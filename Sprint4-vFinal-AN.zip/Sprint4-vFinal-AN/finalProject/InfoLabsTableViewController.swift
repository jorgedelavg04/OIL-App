//
//  InfoLabsTableViewController.swift
//  finalProject
//
//  Created by Mac Produccion on 4/7/19.
//  Copyright © 2019 ITESM CCM. All rights reserved.
//

import UIKit

class InfoLabsTableViewController: UITableViewController {
    
    var recibirPiso = ""
    var recibirHorario = ""
    var recibirUbicacion = ""
    var recibirImagen = ""
    var recibirNombre = ""
    var recibirFotos: [[String:Any]] = []
    var recibirVideos: [[String:Any]] = []
    var recibirVideosRA: [[String:Any]] = []
    var recibirVideos360: [[String:Any]] = []
    var recibirRA: [[String:Any]] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 9
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        switch section {
        case 0: return "Número del salón"
        case 1: return "Nombre del salón"
        case 2: return "Horario"
        case 3: return "Piso"
        case 4: return "Fotos"
        case 5: return "Videos"
        case 6: return "Videos RA"
        case 7: return "Videos 360"
        case 8: return "Realidad Aumentada"
        default: return nil
        }
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        let numFotos = recibirFotos.count
        let numVideos = recibirVideos.count
        let numVideosRA = recibirVideosRA.count
        let numVideos360 = recibirVideos360.count
        let numRA = recibirRA.count
        
        switch section {
            case 0: return 1
            case 1: return 1
            case 2: return 1
            case 3: return 1
            case 4: return numFotos
            case 5: return numVideos
            case 6: return numVideosRA
            case 7: return numVideos360
            case 8: return numRA
            default: return 0
        }
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: "zelda1")
        
        if(cell == nil){
            cell  = UITableViewCell(style:  UITableViewCell.CellStyle.default,    reuseIdentifier: "zelda")
        }
        
        switch indexPath.section {
            case 0: cell?.textLabel?.text = recibirUbicacion
            case 1: cell?.textLabel?.text = recibirNombre
            case 2: cell?.textLabel?.text = recibirHorario
            case 3: cell?.textLabel?.text = recibirPiso
            case 4: cell?.textLabel?.text = recibirFotos[indexPath.row]["name"] as? String
            case 5: cell?.textLabel?.text = recibirVideos[indexPath.row]["name"] as? String
            case 6: cell?.textLabel?.text = recibirVideosRA[indexPath.row]["name"] as? String
            case 7: cell?.textLabel?.text = recibirVideos360[indexPath.row]["name"] as? String
            case 8: cell?.textLabel?.text = recibirRA[indexPath.row]["name"] as? String
            default: cell?.textLabel?.text = ""
            }
        
            cell?.textLabel?.numberOfLines = 0
            cell?.textLabel?.lineBreakMode = NSLineBreakMode.byWordWrapping
            cell?.textLabel?.sizeToFit()
        
            return cell!
    }
 

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    
   
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        switch indexPath.section{
            case 0: print("test")
            case 1: print("test")
            case 2: print("test")
            case 3: print("test")
            case 4:
                 let siguienteVista = self.storyboard?.instantiateViewController(withIdentifier: "BufferPano") as! BufferPanoViewController
                 let textura = recibirFotos[indexPath.row]["url"] as! String
                 
                 siguienteVista.recibirPano = textura
                 
                 self.navigationController?.pushViewController(siguienteVista, animated: true)
            
            case 5:
                let siguienteVista = self.storyboard?.instantiateViewController(withIdentifier: "VideoYoutube") as! VideoYT
                let video = recibirVideos[indexPath.row]["url"] as! String
                let name = recibirVideos[indexPath.row]["name"] as! String
                
                print(video)
                print(name)
                
                siguienteVista.recibirVideo = video
   
            self.navigationController?.pushViewController(siguienteVista, animated: true)

            case 6:
                let siguienteVista = self.storyboard?.instantiateViewController(withIdentifier: "ARPresentacion") as! PresentacionAR
                
                let video = recibirVideosRA[indexPath.row]["url"] as! String
                
                print(video)
                siguienteVista.recibirVideoRA = video
            
                self.navigationController?.pushViewController(siguienteVista, animated: true)
            
            case 7:
                let siguienteVista = self.storyboard?.instantiateViewController(withIdentifier: "Video360") as! Video360ViewController
                let video360 = recibirVideos360[indexPath.row]["url"] as! String
                
                siguienteVista.moviePath = video360
                
                self.navigationController?.pushViewController(siguienteVista, animated: true)
            case 8: print("test")
                let siguienteVista = self.storyboard?.instantiateViewController(withIdentifier: "ModeloView") as! ModeloViewController
                let escena = recibirRA[indexPath.row]["url"] as! String
                let nombreRa = recibirRA[indexPath.row]["name"] as! String
            let nodoRa = recibirRA[indexPath.row]["nodos"] as! [[String:Any]]
                //let texturaRa = recibirRA[indexPath.row]["textura"] as! String
            
                    siguienteVista.recibirEscena = escena
                    siguienteVista.recibirNombre = nombreRa
                    siguienteVista.recibirNodos = nodoRa
                    //siguienteVista.recibirTextura = texturaRa
            
                self.navigationController?.pushViewController(siguienteVista, animated: true)
            default: print("test")
        }
       
        
    }

}
