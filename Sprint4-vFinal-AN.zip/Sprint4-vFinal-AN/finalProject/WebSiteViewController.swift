//
//  WebSiteViewController.swift
//  finalProject
//
//  Created by Shinell Silva on 5/1/19.
//  Copyright © 2019 ITESM CCM. All rights reserved.
//

import UIKit
import WebKit

class WebSiteViewController: UIViewController, WKUIDelegate, WKNavigationDelegate{

    
    @IBOutlet var webview: WKWebView!
    weak var activityIndicator: UIActivityIndicatorView?
    var recibirURL = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let activityIndicator = UIActivityIndicatorView(style: .gray)
        activityIndicator.startAnimating()
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(activityIndicator)
        NSLayoutConstraint.activate([view.centerXAnchor.constraint(equalTo: activityIndicator.centerXAnchor, constant: 0),
                                     view.centerYAnchor.constraint(equalTo: activityIndicator.centerYAnchor, constant: 0)])
        self.activityIndicator = activityIndicator
        

        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
         webview.uiDelegate = self
        
        let myURL = URL(string: recibirURL)
        let myRequest = URLRequest(url: myURL!)
        webview.load(myRequest)
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if webview.isLoading == true {
           activityIndicator?.stopAnimating()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func getVideo(videoCode: String) {
        let urlVideo = URL(string: recibirURL)
        webview.load(URLRequest(url: urlVideo!))
    }
}


