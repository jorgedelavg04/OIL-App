//
//  LabsTableViewController.swift
//  finalProject
//
//  Created by ITESM CCM on 3/14/19.
//  Copyright © 2019 ITESM CCM. All rights reserved.
//

import UIKit

class LabsTableViewController: UITableViewController, UISearchResultsUpdating {

    func updateSearchResults(for searchController: UISearchController) {
        // si la caja de búsqueda es vacía, entonces mostrar todos los resultados
        if searchController.searchBar.text! == "" {
            datosFiltrados = nuevoArray!
        } else {
            // Filtrar los resultados de acuerdo al texto escrito en la caja que es obtenido a través del parámetro $0
            datosFiltrados = nuevoArray!.filter{
                let objetoLab=$0 as! [String:Any]
                let s:String = objetoLab["nombre"] as! String;
                return(s.lowercased().contains(searchController.searchBar.text!.lowercased())) }
        }
        
        self.tableView.reloadData()
    }
    
    var datosFiltrados = [Any]()
    var nuevoArray:[Any]?
    let searchController = UISearchController(searchResultsController: nil)
    
    let datosNube = "http://martinmolina.com.mx/201911/data/memelords/laboratorios.json"
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
        
        let datosNubeURL = URL(string: datosNube)
        let datos = try? Data(contentsOf: datosNubeURL!)
        nuevoArray = try! JSONSerialization.jsonObject(with: datos!) as? [Any]
        
        datosFiltrados = nuevoArray!
        searchController.searchResultsUpdater = self
        
        searchController.dimsBackgroundDuringPresentation = false
        
        searchController.hidesNavigationBarDuringPresentation = false
        
        definesPresentationContext = true
        
        tableView.tableHeaderView = searchController.searchBar
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return (datosFiltrados.count)
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell = tableView.dequeueReusableCell(withIdentifier: "zelda")
        if(cell == nil){
            cell  = UITableViewCell(style:  UITableViewCell.CellStyle.default,    reuseIdentifier: "zelda")
        }
        // Configure the cell...
        let objetoLab = datosFiltrados[indexPath.row] as! [String:Any]
        let nombreLab:String = objetoLab["nombre"] as! String
        cell?.textLabel?.text = nombreLab
        
        return cell!
    }
 

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        var indice = 0
        var objetoLab = [String:Any]()
        //Paso 15: crear un identificador para el controlador de vista a nivel detalle
        let siguienteVista = self.storyboard?.instantiateViewController(withIdentifier: "InfoLabsTable") as! InfoLabsTableViewController
        //Verificar si la vista actual es la de búsqueda
        if (self.searchController.isActive)
        {
            indice = indexPath.row
            objetoLab = datosFiltrados[indice] as! [String: Any]
            
        }
            //sino utilizar la vista sin filtro
        else
        {
            indice = indexPath.row
            objetoLab = nuevoArray![indice] as! [String: Any]
        }
        let nombre:String = objetoLab["nombre"] as! String
        let piso:String = objetoLab["piso"] as! String
        let ubicacion:String = objetoLab["id"] as! String
        let horario:String = objetoLab["horario"] as! String
        let fotos = objetoLab["photos"] as! [[String: Any]]
        let videos = objetoLab["video"] as! [[String: Any]]
        let videosRA = objetoLab["videora"] as! [[String: Any]]
        let videos360 = objetoLab["video360"] as! [[String: Any]]
        let listaRA = objetoLab["ra"] as! [[String: Any]]
        let imagen:String
        if(objetoLab["fotoInfo"] != nil){
            imagen = objetoLab["fotoInfo"] as! String
        }
        else{
            
            imagen = "https://www.blakleysflooring.com/wp-content/uploads/2016/03/Placeholder.png"
        }
        
        siguienteVista.recibirPiso = piso
        siguienteVista.recibirUbicacion = ubicacion
        siguienteVista.recibirHorario = horario
        siguienteVista.recibirImagen = imagen
        siguienteVista.recibirFotos = fotos
        siguienteVista.recibirNombre = nombre
        siguienteVista.recibirVideos = videos
        siguienteVista.recibirVideosRA = videosRA
        siguienteVista.recibirVideos360 = videos360
        siguienteVista.recibirRA = listaRA
        
        self.navigationController?.pushViewController(siguienteVista, animated: true)
        
    }

}
