//
//  RSSDetailTableViewController.swift
//  finalProject
//
//  Created by Shinell Silva on 5/1/19.
//  Copyright © 2019 ITESM CCM. All rights reserved.
//

import UIKit
import FeedKit
import Foundation

class RSSDetailTableViewController: UITableViewController {

    var feed: RSSFeed?
    
    let parser = FeedParser(URL: feedURL)
    
    var recibirDesc = ""
    var recibirAutor = ""
    var recibirLink = ""
    var recibirTitulo = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Feed"
        
        // Parse asynchronously, not to block the UI.
        parser.parseAsync { [weak self] (result) in
            self?.feed = result.rssFeed
            
            // Then back to the Main thread to update the UI.
            DispatchQueue.main.async {
                self?.tableView.reloadData()
            }
            
        }
        
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 4
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        switch section {
        case 0: return "Título"
        case 1: return "Autor"
        case 2: return "Link"
        case 3: return "Descripción"
        default: return nil
        }
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        switch section {
        case 0: return 1
        case 1: return 1
        case 2: return 1
        case 3: return 1
        default: return 0
        }
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: "zelda1")
        
        if(cell == nil){
            cell  = UITableViewCell(style:  UITableViewCell.CellStyle.default,    reuseIdentifier: "zelda")
        }
        
        switch indexPath.section {
        case 0: cell?.textLabel?.text = recibirTitulo
        case 1: cell?.textLabel?.text = recibirAutor
        case 2: cell?.textLabel?.text = recibirLink
        case 3: cell?.textLabel?.text = recibirDesc
        default: cell?.textLabel?.text = "[error]"
        }
        
        cell?.textLabel?.numberOfLines = 0
        cell?.textLabel?.lineBreakMode = NSLineBreakMode.byWordWrapping
        cell?.textLabel?.sizeToFit()
        
        return cell!
    }

    /*
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)

        // Configure the cell...

        return cell
    }
    */

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        switch indexPath.section{
        case 0: print("test")
        case 1: print("test")
        case 2:
            let siguienteVista = self.storyboard?.instantiateViewController(withIdentifier: "WebView") as! WebSiteViewController
            
            siguienteVista.recibirURL = recibirLink
            
            self.navigationController?.pushViewController(siguienteVista, animated: true)
            
        case 3: print("test")
            /*let siguienteVista = self.storyboard?.instantiateViewController(withIdentifier: "RSSDetail") as! RSSDetailTableViewController
            
            let descripcion = self.feed?.items?[indexPath.row].description as! String
            let autor = self.feed?.items?[indexPath.row].author as! String
            let titulo = self.feed?.items?[indexPath.row].title as! String
            let link = self.feed?.items?[indexPath.row].link as! String
            
            siguienteVista.recibirDesc = descripcion
            siguienteVista.recibirAutor = autor
            siguienteVista.recibirTitulo = titulo
            siguienteVista.recibirLink = link
            
            self.navigationController?.pushViewController(siguienteVista, animated: true)*/
            
        default: print("test")
        }
        
    }
}
