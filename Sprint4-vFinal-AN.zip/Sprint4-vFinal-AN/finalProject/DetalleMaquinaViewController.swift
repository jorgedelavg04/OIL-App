//
//  DetalleMaquinaViewController.swift
//  finalProject
//
//  Created by cdt307 on 3/19/19.
//  Copyright © 2019 ITESM CCM. All rights reserved.
//

import UIKit

class DetalleMaquinaViewController: UIViewController {

    var nombreRecibido = ""
    var descripcionRecibida = ""
    var salonRecibido = ""
    var urlKey = ""
    
    @IBOutlet weak var nombre: UILabel!
    
    @IBOutlet weak var descripcion: UITextView!
    
    @IBOutlet weak var salones: UILabel!
    
    @IBOutlet weak var imagenComputadora: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        nombre.text = nombreRecibido
        descripcion.text = descripcionRecibida
        salones.text = salonRecibido
        descripcion.layer.cornerRadius = 5
        descripcion.layer.borderWidth = 0.5
        
    
        if let url = URL(string: urlKey) {
            
            do {
                let data = try Data(contentsOf: url)
                self.imagenComputadora.image = UIImage(data: data)
            }catch let err {
                print("Error: \(err.localizedDescription)")
            }
            
            
        }
    
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    

}
