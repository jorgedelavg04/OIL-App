//
//  TareaViewController.swift
//  finalProject
//
//  Created by cdt307 on 4/2/19.
//  Copyright © 2019 ITESM CCM. All rights reserved.
//

import UIKit
import Firebase
import Darwin

class TareaViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, AgregarTarea, completar{

    
    
    @IBOutlet weak var tableView: UITableView!
    
    let ref = Database.database().reference()
    
    var tareas: [Tarea] = []
    
    let userid = Auth.auth().currentUser?.uid
    
    @IBAction func borrarTarea(_ sender: UIButton) {
        var superview = sender.superview
        while let view = superview, !(view is UITableViewCell) {
            superview = view.superview
        }
        guard let cell = superview as? UITableViewCell else {
            print("button is not contained in a table view cell")
            return
        }
        guard let indexPath = tableView.indexPath(for: cell) else {
            print("failed to get index path for cell containing button")
            return
        }
        
        let tarID = tareas[indexPath.row].tID
        
        ref.child("Usuarios").child(userid!).child(tarID).removeValue()
        
        
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ref.child("Usuarios").child(userid!).observe(.value, with: {(snap: DataSnapshot) in
            self.tareas.removeAll()
            for child in snap.children {
                if let child = child as? DataSnapshot {
                    let snapshotDictionnary = child.value! as? [String: AnyObject]
                    let tarea = snapshotDictionnary?["Tarea"] as! String
                    let id = child.key
                    // etc...
                    self.tareas.append(Tarea(nombre: tarea, id: id))
                }
            }
            
            self.tableView.reloadData()
        })
        tableView.reloadData()
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tareas.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let celda = tableView.dequeueReusableCell(withIdentifier: "tareaCell", for: indexPath) as! TareaCell
        
        celda.tareaLabel.text = tareas[indexPath.row].nombre
        
        if tareas[indexPath.row].completado {
            celda.checkBox.setBackgroundImage(UIImage(named: "Filled"), for: UIControl.State.normal)
        } else {
            celda.checkBox.setBackgroundImage(UIImage(named: "Outline"), for: UIControl.State.normal)
        }
        
        celda.delegate = self
        celda.indexP = indexPath.row
        celda.tareas = tareas
        
        return celda
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as! AgregarTareaViewController
        vc.delegate = self
    }
    
    func agregarTarea(nombre: String) {
        tableView.reloadData()
    }
    
    func completar(completado: Bool, index: Int){
        tareas[index].completado = completado
        tableView.reloadData()
    }

}

class Tarea{
    var nombre = ""
    var completado = false
    var tID = ""
    
    convenience init(nombre: String, id: String){
        self.init()
        self.nombre = nombre
        self.tID = id
    }
}
