//
//  LoginViewController.swift
//  finalProject
//
//  Created by cdt307 on 4/29/19.
//  Copyright © 2019 ITESM CCM. All rights reserved.
//

import UIKit
import Firebase

class LoginViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var correo: UITextField!
    @IBOutlet weak var contraseña: UITextField!
    weak var activityIndicator: UIActivityIndicatorView?
    
    
    @IBAction func hacerLogin(_ sender: Any) {
        self.activityIndicator?.startAnimating()
        Auth.auth().signIn(withEmail: correo.text!, password: contraseña.text!){
            (user, error) in
            if error != nil{
                self.activityIndicator?.stopAnimating()
                print(error!)
                let alert = UIAlertController(title: "Error", message: "El correo o la contraseña son incorrectos", preferredStyle: .alert)
                
                
                alert.addAction(UIAlertAction(title: "continue", style: .default, handler: nil))
                
                self.present(alert, animated: true)
            }else{
                print("Login exitoso")
                self.performSegue(withIdentifier: "Entrar", sender: self)
                
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        contraseña.delegate = self
        correo.delegate = self
        self.hideKeyboardWhenTappedAround()
        // Do any additional setup after loading the view.
        let activityIndicator = UIActivityIndicatorView(style: .gray)
        activityIndicator.color = .black
        
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(activityIndicator)
        NSLayoutConstraint.activate([view.centerXAnchor.constraint(equalTo: activityIndicator.centerXAnchor, constant: 0),
                                     view.centerYAnchor.constraint(equalTo: activityIndicator.centerYAnchor, constant: 0)])
        self.activityIndicator = activityIndicator
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        if textField == correo {
            contraseña.becomeFirstResponder()
        } else if textField == contraseña {
            self.view.endEditing(true)
        }
        return true
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
