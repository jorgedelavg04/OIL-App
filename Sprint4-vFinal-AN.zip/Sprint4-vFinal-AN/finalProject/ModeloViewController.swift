//
//  ModeloViewController.swift
//  finalProject
//
//  Created by cdt307 on 4/9/19.
//  Copyright © 2019 ITESM CCM. All rights reserved.
//

import UIKit
import SceneKit
import ARKit
import Kingfisher

class ModeloViewController: UIViewController, ARSCNViewDelegate {
    
    
    
    @IBOutlet weak var escena: ARSCNView!
    
    
    var recibirEscena = ""
    var recibirNombre = ""
    var recibirNodos:[[String:Any]] = [["":""]]
    var recibirTextura = ""
    var node = SCNNode()
    var nodesText = [SCNNode()]
    var nodeText = SCNNode()
    var hidden = true
    weak var activityIndicator: UIActivityIndicatorView?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        escena.alpha = 0
        view.backgroundColor = #colorLiteral(red: 0.3173043132, green: 0.4565047026, blue: 0.5755147934, alpha: 1)
        
        escena.isPlaying = false
        escena.session.delegate = self as ARSessionDelegate
        
        let activityIndicator = UIActivityIndicatorView(style: .gray)
        activityIndicator.startAnimating()
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(activityIndicator)
        NSLayoutConstraint.activate([view.centerXAnchor.constraint(equalTo: activityIndicator.centerXAnchor, constant: 0),
                                     view.centerYAnchor.constraint(equalTo: activityIndicator.centerYAnchor, constant: 0)])
        self.activityIndicator = activityIndicator
        
        escena.autoenablesDefaultLighting = true
    }
    
    private func loadScene() {
        
        SCNTransaction.begin()
        SCNTransaction.disableActions = true
        
        let alert = UIAlertController(title: "Hint", message: "Para aparecer la figura haz tap en la pantalla", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        self.present(alert, animated: true)
        
        escena.delegate = self
        
        let material = SCNMaterial()
        
        /*do {
         //let myURL = NSURL(string: recibirEscena)
         //let scene = try SCNScene(url: myURL! as URL, options: nil)
         
         } catch {}*/
        do {
            let myURL = NSURL(string: recibirEscena)
            let scene = try SCNScene(url: myURL! as URL, options: nil)
            //let scene = SCNScene(named: "art.scnassets/screwdriver.scn")!
            escena.scene = scene
            node = scene.rootNode.childNode(withName: recibirNombre, recursively: true)!
            for nodoRecibido in recibirNodos{
                let url = NSURL(string: nodoRecibido["textura"] as! String)
                
                KingfisherManager.shared.retrieveImage(with: url! as URL, options: nil, progressBlock: nil) { result in
                    switch result {
                    case .success(let value):
                        print("Image: \(value.image). Got from: \(value.cacheType)")
                        material.diffuse.contents = value.image
                    case .failure(let error):
                        print("Error: \(error)")
                    }
                }
                nodeText = scene.rootNode.childNode(withName: nodoRecibido["nombre"] as! String, recursively: true)!
                nodeText.geometry?.firstMaterial = material
                nodesText.append(nodeText)
            }
            node.isHidden = true
            
            let pinchGestureRecognizer = UIPinchGestureRecognizer (target: self, action: #selector(escalar))
            let rotationGestureRecognizer = UIRotationGestureRecognizer (target: self, action: #selector(rotacion))
            let tapGestureRecognizer = UITapGestureRecognizer (target: self, action: #selector(tapModelo))
            
            escena.addGestureRecognizer(pinchGestureRecognizer)
            escena.addGestureRecognizer(rotationGestureRecognizer)
            escena.addGestureRecognizer(tapGestureRecognizer)
        }catch{
            
        }
        SCNTransaction.commit()
        
        self.isLoading = false
        
    }
    
    @objc func rotacion(_ sender: UIRotationGestureRecognizer) {
        
        node.eulerAngles = SCNVector3(0,sender.rotation,0)
        
    }
    
    @objc func tapModelo(_ sender: UITapGestureRecognizer) {
        
        if (node.isHidden){
            node.isHidden = false
        }else{
            node.isHidden = true
        }
        
    }
    
    
    @objc func escalar(recognizer:UIPinchGestureRecognizer) {
        
        node.scale = SCNVector3(recognizer.scale, recognizer.scale, recognizer.scale)
        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Create a session configuration
        let configuration = ARWorldTrackingConfiguration()
        
        // Run the view's session
        escena.session.run(configuration)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        // Pause the view's session
        escena.session.pause()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Release any cached data, images, etc that aren't in use.
    }
    
    
    @IBAction func rotar(_ sender: Any) {
        
    }
    
    func session(_ session: ARSession, didFailWithError error: Error) {
        // Present an error message to the user
        
    }
    
    func sessionWasInterrupted(_ session: ARSession) {
        // Inform the user that the session has been interrupted, for example, by presenting an overlay
        
    }
    
    func sessionInterruptionEnded(_ session: ARSession) {
        // Reset tracking and/or remove existing anchors if consistent tracking is required
        
    }
    
    var isLoading = true
    var hasLoaded = false
}



extension ModeloViewController: ARSessionDelegate {
    
    func session(_ session: ARSession, didUpdate frame: ARFrame) {
        
        // Waiting until after the session starts prevents objects from jumping around
        if hasLoaded == false {
            hasLoaded = true
            
            loadScene()
            
        } else if isLoading == false {
            guard let activityIndicator = self.activityIndicator else { return }
            
            DispatchQueue.main.async {
                UIView.animate(withDuration: 0.40, animations: { [weak self] in
                    self?.escena.alpha = 1
                    activityIndicator.alpha = 0
                    }, completion: { _ in
                        activityIndicator.removeFromSuperview()
                })
            }
        }
    }
}

