////
//  RSSTableViewController.swift
//  finalProject
//
//  Created by Shinell Silva on 4/30/19.
//  Copyright © 2019 ITESM CCM. All rights reserved.
//

import UIKit
import FeedKit
import Foundation


let feedURL = URL(string: "http://martinmolina.com.mx/201911/data/memelords/oil.xml")!
var activityIndicatorView: UIActivityIndicatorView!
let dispatchQueue = DispatchQueue(label: "Example Queue")

class RSSTableViewController: UITableViewController {
    
    var feed: RSSFeed?
    
    let parser = FeedParser(URL: feedURL)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Feed"
        
        // Parse asynchronously, not to block the UI.
        parser.parseAsync { [weak self] (result) in
            self?.feed = result.rssFeed
            
            // Then back to the Main thread to update the UI.
            DispatchQueue.main.async {
                self?.tableView.reloadData()
            }
            
        }
        
    }
    // MARK: - Table view data source
    
    @IBOutlet weak var viewRss: UIView!
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 4
    }
    
    
    override func loadView() {
        super.loadView()
        
        activityIndicatorView = UIActivityIndicatorView(style: .gray)
        tableView.backgroundView = activityIndicatorView
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        switch section {
        case 0: return "Feed"
        case 1: return "Link"
        case 2: return "Descripción"
        case 3: return "Artículos"
        default: return nil
        }
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        
        
        switch section {
        case 0: return 1
        case 1: return 1
        case 2: return 1
        case 3: return self.feed?.items?.count ?? 0
        default: return 0
        }
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: "zelda1")
        
        if(cell == nil){
            cell  = UITableViewCell(style:  UITableViewCell.CellStyle.default,    reuseIdentifier: "zelda")
            activityIndicatorView.startAnimating()
           
        }
        
        switch indexPath.section {
        case 0: cell?.textLabel?.text = self.feed?.title
            activityIndicatorView.stopAnimating()
        case 1: cell?.textLabel?.text = self.feed?.link
        case 2: cell?.textLabel?.text = self.feed?.description
        case 3: cell?.textLabel?.text = self.feed?.items?[indexPath.row].title
            activityIndicatorView.stopAnimating()
        default: cell?.textLabel?.text = ""
            
        }
        
        cell?.textLabel?.numberOfLines = 0
        cell?.textLabel?.lineBreakMode = NSLineBreakMode.byWordWrapping
        cell?.textLabel?.sizeToFit()
        return cell!
        
        
    }
    

    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

        switch indexPath.section{
        case 0: print("test")
        case 1:
            let siguienteVista = self.storyboard?.instantiateViewController(withIdentifier: "WebView") as! WebSiteViewController
            
            siguienteVista.recibirURL = self.feed!.link!
            
            self.navigationController?.pushViewController(siguienteVista, animated: true)
        case 2: print("test")
        case 3:
            let siguienteVista = self.storyboard?.instantiateViewController(withIdentifier: "RSSDetail") as! RSSDetailTableViewController
            
            let descripcion = self.feed?.items?[indexPath.row].description
            let autor = self.feed?.items?[indexPath.row].author
            let titulo = self.feed?.items?[indexPath.row].title
            let link = self.feed?.items?[indexPath.row].link
            
            siguienteVista.recibirDesc = descripcion!
            siguienteVista.recibirAutor = autor!
            siguienteVista.recibirTitulo = titulo!
            siguienteVista.recibirLink = link!
            
            
            self.navigationController?.pushViewController(siguienteVista, animated: true)
            
        default: print("test")
            
        }
    }
}
