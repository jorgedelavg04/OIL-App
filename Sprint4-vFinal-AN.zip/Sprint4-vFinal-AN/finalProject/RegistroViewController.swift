//
//  RegistroViewController.swift
//  finalProject
//
//  Created by cdt307 on 4/29/19.
//  Copyright © 2019 ITESM CCM. All rights reserved.
//

import UIKit
import Firebase

class RegistroViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var Correo: UITextField!
    @IBOutlet weak var contraseña: UITextField!
    var bienHecho = false
    weak var activityIndicator: UIActivityIndicatorView?
    
    
    @IBAction func registrarUsuario(_ sender: Any) {
        self.activityIndicator?.startAnimating()
        Auth.auth().createUser(withEmail: Correo.text!, password: contraseña.text!){(Correo, error) in
            
            if error != nil{
                self.activityIndicator?.stopAnimating()
                print(error!)
                
            }
            else{
                self.bienHecho = true
                print("Registro de usuario exitoso")
               
                self.performSegue(withIdentifier: "Registro", sender: self)
                
                
                
               
            }
            
             if !self.Correo.text!.contains("@") {
                let alert = UIAlertController(title: "Error", message: "Ingresa un correo válido", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Regresar", style: .default, handler: nil))
                self.present(alert, animated: true)
             } else if self.contraseña.text!.count < 6 {
                let alert = UIAlertController(title: "Error", message: "La contraseña debe tener al menos 6 caracteres", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Regresar", style: .default, handler: nil))
                self.present(alert, animated: true)
            }
            
            
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Correo.delegate = self
        contraseña.delegate = self
        self.hideKeyboardWhenTappedAround()
        
        
        
        
        let activityIndicator = UIActivityIndicatorView(style: .gray)
        activityIndicator.color = .black
        
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(activityIndicator)
        NSLayoutConstraint.activate([view.centerXAnchor.constraint(equalTo: activityIndicator.centerXAnchor, constant: 0),
                                     view.centerYAnchor.constraint(equalTo: activityIndicator.centerYAnchor, constant: 0)])
        self.activityIndicator = activityIndicator
        // Do any additional setup after loading the view.
    }
 /*
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return true
    }
 */
 
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        if textField == Correo {
             contraseña.becomeFirstResponder()
        } else if textField == contraseña {
            self.view.endEditing(true)
        }
        return true
    }
    
    
        
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */

    



