//
//  TareaCell.swift
//  finalProject
//
//  Created by cdt307 on 4/2/19.
//  Copyright © 2019 ITESM CCM. All rights reserved.
//

import UIKit
import Firebase

protocol completar{
    func completar(completado: Bool, index: Int)
}

class TareaCell: UITableViewCell {

    @IBOutlet weak var checkBox: UIButton!
    
    @IBOutlet weak var tareaLabel: UILabel!
    
    let userid = Auth.auth().currentUser?.uid
    
    
    @IBAction func checkBoxAccion(_ sender: Any) {
        if tareas![indexP!].completado {
            delegate?.completar(completado: false, index: indexP!)
        } else {
            delegate?.completar(completado: true, index: indexP!)
        }
    }
    
    var delegate: completar?
    var indexP: Int?
    var tareas: [Tarea]?
    
    
}
