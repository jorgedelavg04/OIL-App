//
//  NoNavViewController.swift
//  finalProject
//
//  Created by cdt307 on 3/19/19.
//  Copyright © 2019 ITESM CCM. All rights reserved.
//

import UIKit
import Firebase

class NoNavViewController: UIViewController {
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.setHidesBackButton(true, animated: true)
        //For Start Activity Indicator        // Do any additional setup after loading the view.
    }
    
    @IBAction func hacerLogout(_ sender: Any) {
        do{
            //Método para cirre de sesión
            try Auth.auth().signOut()
            //Regresa a la vista raíz del navegador
            self.view.window?.rootViewController?.dismiss(animated: true, completion: nil)
            
        }catch{
            print("Error en logout")
            let alert = UIAlertController(title: "Error", message: "Error en Logout", preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title: "continue", style: .default, handler: nil))
            
            self.present(alert, animated: true)
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
