//
//  Video360ViewController.swift
//  finalProject
//
//  Created by ITESM CCM on 4/10/19.
//  Copyright © 2019 ITESM CCM. All rights reserved.
//

import UIKit
import SceneKit
import ARKit
import AVFoundation

class Video360ViewController: UIViewController, ARSCNViewDelegate {
    
    @IBOutlet var sceneView: ARSCNView!
    
    var moviePath = ""
    var exists = false
    weak var activityIndicator: UIActivityIndicatorView?
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set the view's delegate
        
        sceneView.alpha = 0
        view.backgroundColor = #colorLiteral(red: 0.3173043132, green: 0.4565047026, blue: 0.5755147934, alpha: 1)
        
        sceneView.isPlaying = false
        sceneView.session.delegate = self as? ARSessionDelegate
        
        let activityIndicator = UIActivityIndicatorView(style: .gray)
        activityIndicator.startAnimating()
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(activityIndicator)
        NSLayoutConstraint.activate([view.centerXAnchor.constraint(equalTo: activityIndicator.centerXAnchor, constant: 0),
                                     view.centerYAnchor.constraint(equalTo: activityIndicator.centerYAnchor, constant: 0)])
        self.activityIndicator = activityIndicator
        
        sceneView.autoenablesDefaultLighting = true
        // Do any additional setup after loading the view.
    }
    
    /*
     sceneView.delegate = self
     
     // Show statistics such as fps and timing information
     sceneView.showsStatistics = true
     
     // Create a new scene
     let scene = SCNScene()
     
     // Set the scene to the view
     sceneView.scene = scene
     registerGestureRecognizer()
     */
    
    private func loadScene() {
        
        SCNTransaction.begin()
        SCNTransaction.disableActions = true
        
        
        
        
        
        
        
        sceneView.delegate = self
        
        // Show statistics such as fps and timing information
        sceneView.showsStatistics = true
        
        // Create a new scene
        let scene = SCNScene()
        
        // Set the scene to the view
        sceneView.scene = scene
        //registerGestureRecognizer()
        
        let url = URL(string: moviePath)
        
        // crear un nodo capaz de reporducir un video
        let videoNodo = SKVideoNode(url: url!)
        videoNodo.play() //ejecutar play al momento de presentarse
        
        //crear una escena sprite kit, los parametros estan en pixeles
        let spriteKitEscene =  SKScene(size: CGSize(width: 1024, height: 512))
        
        
        //colocar el videoNodo en el centro de la escena tipo SpriteKit
        videoNodo.position = CGPoint(x: spriteKitEscene.size.width/2, y: spriteKitEscene.size.height/2)
        videoNodo.size = spriteKitEscene.size
        spriteKitEscene.addChild(videoNodo)
        
        //__________
        let esfera = SCNSphere(radius: 20.0)
        let materialTierra = SCNMaterial()
        materialTierra.diffuse.contents = spriteKitEscene//UIImage(named:"307Gear.JPG")
        materialTierra.isDoubleSided = true
        
        var transform = SCNMatrix4MakeRotation(Float.pi, 0.0, 0.0, 1.0)
        transform = SCNMatrix4Translate(transform, 1.0, 1.0, 0)
        materialTierra.diffuse.contentsTransform = transform
        let tierra = SCNNode()
        tierra.geometry = esfera
        tierra.geometry?.materials = [materialTierra]
        
        tierra.position = SCNVector3(x:0, y:0, z:0)
        
        //identificar en donde se ha tocado el currentFrame
        var traduccion = matrix_identity_float4x4
        //definir un metro alejado del dispositivo
        traduccion.columns.3.z = -1.0
        //pantallaPlanaNodo.eulerAngles = SCNVector3(Double.pi, 0, 0)
        self.sceneView.scene.rootNode.addChildNode(tierra)
        exists = true
        
        
        SCNTransaction.commit()
        
        
        self.isLoading = false
        
    }
    
    /*private func registerGestureRecognizer(){
        let tapGesto = UITapGestureRecognizer(target: self, action: #selector(tapEnPantalla))
        self.sceneView.addGestureRecognizer(tapGesto)
    }*/
    
    /*@objc func tapEnPantalla(manejador:UIGestureRecognizer)
    {
        
        
        if(exists == false){
            //currentFrame es la imagen actual de la camara
            
            guard self.sceneView.session.currentFrame != nil else {return}
            
            let url = URL(string: moviePath)
            
            // crear un nodo capaz de reporducir un video
            let videoNodo = SKVideoNode(url: url!)
            videoNodo.play() //ejecutar play al momento de presentarse
            
            //crear una escena sprite kit, los parametros estan en pixeles
            let spriteKitEscene =  SKScene(size: CGSize(width: 1024, height: 512))
            
            
            //colocar el videoNodo en el centro de la escena tipo SpriteKit
            videoNodo.position = CGPoint(x: spriteKitEscene.size.width/2, y: spriteKitEscene.size.height/2)
            videoNodo.size = spriteKitEscene.size
            spriteKitEscene.addChild(videoNodo)
            
            //__________
            let esfera = SCNSphere(radius: 20.0)
            let materialTierra = SCNMaterial()
            materialTierra.diffuse.contents = spriteKitEscene//UIImage(named:"307Gear.JPG")
            materialTierra.isDoubleSided = true
            
            var transform = SCNMatrix4MakeRotation(Float.pi, 0.0, 0.0, 1.0)
            transform = SCNMatrix4Translate(transform, 1.0, 1.0, 0)
            materialTierra.diffuse.contentsTransform = transform
            let tierra = SCNNode()
            tierra.geometry = esfera
            tierra.geometry?.materials = [materialTierra]
            
            tierra.position = SCNVector3(x:0, y:0, z:0)
            
            //identificar en donde se ha tocado el currentFrame
            var traduccion = matrix_identity_float4x4
            //definir un metro alejado del dispositivo
            traduccion.columns.3.z = -1.0
            //pantallaPlanaNodo.eulerAngles = SCNVector3(Double.pi, 0, 0)
            self.sceneView.scene.rootNode.addChildNode(tierra)
            exists = true
            
            
            
            
            
        }
    }*/
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        // Create a session configuration
        let configuration = ARWorldTrackingConfiguration()
        // Run the view's session
        sceneView.session.run(configuration)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        // Pause the view's session
        sceneView.session.pause()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Release any cached data, images, etc that aren't in use.
    }
    
    func session(_ session: ARSession, didFailWithError error: Error) {
        // Present an error message to the user
    }
    
    func sessionWasInterrupted(_ session: ARSession) {
        // Inform the user that the session has been interrupted, for example, by presenting an overlay
    }
    
    func sessionInterruptionEnded(_ session: ARSession) {
        // Reset tracking and/or remove existing anchors if consistent tracking is required
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    var isLoading = true
    var hasLoaded = false
    
}
extension Video360ViewController: ARSessionDelegate {
    
    
    
    func session(_ session: ARSession, didUpdate frame: ARFrame) {
        
        // Waiting until after the session starts prevents objects from jumping around
        if hasLoaded == false {
            hasLoaded = true
            loadScene()
            
            
            
        } else if isLoading == false {
            guard let activityIndicator = self.activityIndicator else { return }
            
            DispatchQueue.main.async {
                UIView.animate(withDuration: 0.40, animations: { [weak self] in
                    self?.sceneView.alpha = 1
                    activityIndicator.alpha = 0
                    }, completion: { _ in
                        activityIndicator.removeFromSuperview()
                })
            }
        }
    }
}
